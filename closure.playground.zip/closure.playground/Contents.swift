//: Playground - noun: a place where people can play



//builder design pattern
class DeathStarBuilder{
    
    var x : Double?
    var y : Double?
    var z : Double?
    
    typealias BuilderClosure = (DeathStarBuilder) ->()
    
    init(builder : BuilderClosure) {
        builder(self)
    }
}

let empire = DeathStarBuilder{ builder in
    builder.x = 0.2
    builder.y = 0.4
    builder.z = 0.6
    
}

print(empire.x!)


//Higher order function
//function as return value
func doArithmeticOperation(isMultiply:Bool) -> (Double,Double)-> Double{
    
    func multiply(num1:Double,num2:Double) -> Double{
        return num1 * num2
    }
    
    func addition(num1:Double,num2:Double) -> Double{
        return num1 + num2
    }
    
    return isMultiply ? multiply : addition
}

let operationToPerform_1 = doArithmeticOperation(isMultiply: true)
let operationToPerform_2 = doArithmeticOperation(isMultiply: false)

operationToPerform_1(10,2)
operationToPerform_2(10,2)

